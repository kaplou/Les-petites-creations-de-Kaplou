import { Router, type IRouter } from "express";
import { and, count, desc, eq, sql } from "drizzle-orm";
import { db, contactMessagesTable, ordersTable, siteSettingsTable } from "@workspace/db";
import {
  CreateProductBody,
  CreateProductResponse,
  CreateCheckoutBody,
  CreateCheckoutResponse,
  DeleteProductParams,
  GetAdminSummaryResponse,
  GetProductParams,
  GetProductResponse,
  GetSiteSettingsResponse,
  ListNewProductsQueryParams,
  ListNewProductsResponse,
  ListOrdersResponse,
  ListProductsQueryParams,
  ListProductsResponse,
  MarkProductSoldParams,
  MarkProductSoldResponse,
  SendContactMessageBody,
  SendContactMessageResponse,
  UpdateProductBody,
  UpdateProductParams,
  UpdateProductResponse,
  UpdateSiteSettingsBody,
  UpdateSiteSettingsResponse,
} from "@workspace/api-zod";
import { getUncachableStripeClient } from "../stripeClient";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const categories = new Set([
  "drawings",
  "collages-papers",
  "small-sculptures",
  "found-transformed",
]);
const statuses = new Set(["available", "sold", "out"]);

type StripeProductRow = {
  id: string;
  name: string;
  description: string | null;
  metadata: Record<string, string> | null;
  active: boolean | null;
  price_id: string | null;
  unit_amount: number | string | null;
  currency: string | null;
};

function parseJson<T>(value: string | undefined, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function metadataValue(metadata: Record<string, string>, key: string): string | undefined {
  const value = metadata[key];
  return value === "" ? undefined : value;
}

function rowToProduct(row: StripeProductRow) {
  const metadata = row.metadata ?? {};
  const stockValue = metadataValue(metadata, "stock");
  const yearValue = metadataValue(metadata, "year");
  const rawStatus = metadataValue(metadata, "status") ?? "available";
  const rawCategory = metadataValue(metadata, "category") ?? "drawings";
  const unitAmount = Number(row.unit_amount ?? 0);

  return {
    id: row.id,
    title: row.name,
    slug: metadataValue(metadata, "slug") ?? row.id,
    description: row.description ?? "",
    story: metadataValue(metadata, "story") ?? null,
    category: categories.has(rawCategory) ? rawCategory : "drawings",
    price: unitAmount / 100,
    currency: (row.currency ?? metadata.currency ?? "eur").toUpperCase(),
    images: parseJson<string[]>(metadata.images, []),
    stock: stockValue === undefined ? null : Number(stockValue),
    product_type: metadataValue(metadata, "product_type") ?? "unique",
    shipping_type: metadataValue(metadata, "shipping_type") ?? "shipping",
    shipping_price: Number(metadataValue(metadata, "shipping_price") ?? 0),
    status: statuses.has(rawStatus) ? rawStatus : "available",
    technique: metadataValue(metadata, "technique") ?? null,
    materials: metadataValue(metadata, "materials") ?? null,
    dimensions: metadataValue(metadata, "dimensions") ?? null,
    year: yearValue === undefined ? null : Number(yearValue),
    featured: metadataValue(metadata, "featured") === "true",
    stripe_product_id: row.id,
    stripe_price_id: row.price_id ?? metadataValue(metadata, "stripe_price_id") ?? null,
    created_at: new Date(metadataValue(metadata, "created_at") ?? Date.now()),
    updated_at: new Date(metadataValue(metadata, "updated_at") ?? Date.now()),
  };
}

async function listStripeProducts(): Promise<ReturnType<typeof rowToProduct>[]> {
  const result = await db.execute(sql`
    SELECT
      p.id,
      p.name,
      p.description,
      p.metadata,
      p.active,
      pr.id AS price_id,
      pr.unit_amount,
      pr.currency
    FROM stripe.products p
    LEFT JOIN stripe.prices pr
      ON pr.product = p.id AND pr.active = true
    ORDER BY p.id DESC
  `);
  return (result.rows as unknown as StripeProductRow[]).map(rowToProduct);
}

function slugify(title: string): string {
  return title
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function productMetadata(input: {
  slug: string;
  story?: string | null;
  category: string;
  images: string[];
  stock: number | null;
  product_type: string;
  shipping_type: string;
  shipping_price: number;
  technique?: string | null;
  materials?: string | null;
  dimensions?: string | null;
  year?: number | null;
  featured: boolean;
  stripe_price_id?: string | null;
  status?: string;
  created_at?: string;
}) {
  return {
    slug: input.slug,
    story: input.story ?? "",
    category: input.category,
    images: JSON.stringify(input.images),
    stock: input.stock === null ? "" : String(input.stock),
    product_type: input.product_type,
    shipping_type: input.shipping_type,
    shipping_price: String(input.shipping_price),
    technique: input.technique ?? "",
    materials: input.materials ?? "",
    dimensions: input.dimensions ?? "",
    year: input.year == null ? "" : String(input.year),
    featured: String(input.featured),
    stripe_price_id: input.stripe_price_id ?? "",
    status: input.status ?? "available",
    created_at: input.created_at ?? new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

async function findProduct(idOrSlug: string) {
  const products = await listStripeProducts();
  return products.find((product) => product.id === idOrSlug || product.slug === idOrSlug);
}

router.get("/products", async (req, res): Promise<void> => {
  const parsed = ListProductsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const products = await listStripeProducts();
  const filtered = products
    .filter((product) => !parsed.data.category || product.category === parsed.data.category)
    .filter((product) => !parsed.data.status || product.status === parsed.data.status)
    .slice(0, parsed.data.limit);
  res.json(ListProductsResponse.parse(filtered));
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const product = await findProduct(params.data.id);
  if (!product) {
    res.status(404).json({ error: "Creation not found" });
    return;
  }
  res.json(GetProductResponse.parse(product));
});

router.post("/products", async (req, res): Promise<void> => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const data = parsed.data;
  const stripe = await getUncachableStripeClient();
  const slug = `${slugify(data.title)}-${Date.now().toString(36)}`;
  const metadata = productMetadata({ ...data, slug });
  const stripeProduct = await stripe.products.create({
    name: data.title,
    description: data.description,
    metadata,
  });
  const stripePrice = await stripe.prices.create({
    product: stripeProduct.id,
    unit_amount: Math.round(data.price * 100),
    currency: data.currency.toLowerCase(),
  });
  await stripe.products.update(stripeProduct.id, {
    metadata: { ...metadata, stripe_price_id: stripePrice.id },
  });
  const product = rowToProduct({
    id: stripeProduct.id,
    name: data.title,
    description: data.description,
    metadata: { ...metadata, stripe_price_id: stripePrice.id },
    active: true,
    price_id: stripePrice.id,
    unit_amount: stripePrice.unit_amount,
    currency: stripePrice.currency,
  });
  res.status(201).json(CreateProductResponse.parse(product));
});

router.patch("/products/:id", async (req, res): Promise<void> => {
  const params = UpdateProductParams.safeParse(req.params);
  const parsed = UpdateProductBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const current = await findProduct(params.data.id);
  if (!current) {
    res.status(404).json({ error: "Creation not found" });
    return;
  }
  const data = parsed.data;
  const stripe = await getUncachableStripeClient();
  const currentMetadata = productMetadata({
    slug: current.slug,
    story: data.story ?? current.story,
    category: data.category ?? current.category,
    images: data.images ?? current.images,
    stock: data.stock === undefined ? current.stock : data.stock,
    product_type: data.product_type ?? current.product_type,
    shipping_type: data.shipping_type ?? current.shipping_type,
    shipping_price: data.shipping_price ?? current.shipping_price,
    technique: data.technique ?? current.technique,
    materials: data.materials ?? current.materials,
    dimensions: data.dimensions ?? current.dimensions,
    year: data.year === undefined ? current.year : data.year,
    featured: data.featured ?? current.featured,
    stripe_price_id: current.stripe_price_id,
    status: data.status ?? current.status,
    created_at: current.created_at.toISOString(),
  });
  let priceId = current.stripe_price_id;
  if (data.price !== undefined && data.price !== current.price) {
    const newPrice = await stripe.prices.create({
      product: current.id,
      unit_amount: Math.round(data.price * 100),
      currency: (data.currency ?? current.currency).toLowerCase(),
    });
    if (priceId) await stripe.prices.update(priceId, { active: false });
    priceId = newPrice.id;
  }
  const updatedMetadata = { ...currentMetadata, stripe_price_id: priceId ?? "" };
  await stripe.products.update(current.id, {
    ...(data.title === undefined ? {} : { name: data.title }),
    ...(data.description === undefined ? {} : { description: data.description }),
    metadata: updatedMetadata,
  });
  const refreshed = await findProduct(current.id);
  res.json(UpdateProductResponse.parse(refreshed ?? { ...current, ...data, stripe_price_id: priceId }));
});

router.delete("/products/:id", async (req, res): Promise<void> => {
  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const current = await findProduct(params.data.id);
  if (!current) {
    res.status(404).json({ error: "Creation not found" });
    return;
  }
  const stripe = await getUncachableStripeClient();
  await stripe.products.update(current.id, { active: false });
  res.sendStatus(204);
});

router.post("/products/:id/mark-sold", async (req, res): Promise<void> => {
  const params = MarkProductSoldParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const current = await findProduct(params.data.id);
  if (!current) {
    res.status(404).json({ error: "Creation not found" });
    return;
  }
  const stripe = await getUncachableStripeClient();
  await stripe.products.update(current.id, {
    metadata: {
      stock: "0",
      status: "sold",
      updated_at: new Date().toISOString(),
    },
  });
  const updated = { ...current, stock: 0, status: "sold" as const };
  res.json(MarkProductSoldResponse.parse(updated));
});

router.get("/new-products", async (req, res): Promise<void> => {
  const parsed = ListNewProductsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const products = await listStripeProducts();
  const sorted = [...products]
    .sort((a, b) => b.created_at.getTime() - a.created_at.getTime())
    .slice(0, parsed.data.limit);
  res.json(ListNewProductsResponse.parse(sorted));
});

router.get("/admin/summary", async (_req, res): Promise<void> => {
  const products = await listStripeProducts();
  const [orderCount] = await db.select({ value: count() }).from(ordersTable);
  const summary = {
    total: products.length,
    available: products.filter((product) => product.status === "available").length,
    sold: products.filter((product) => product.status === "sold").length,
    out: products.filter((product) => product.status === "out").length,
    recent_orders: Number(orderCount?.value ?? 0),
  };
  res.json(GetAdminSummaryResponse.parse(summary));
});

router.get("/settings", async (_req, res): Promise<void> => {
  await db.insert(siteSettingsTable).values({
    id: "main",
    tagline: "Des petites créations uniques, des objets chinés, détournés, dessinés et transformés à l’atelier.",
    aboutText: "Kaplou aime le papier, les objets qui ont vécu et les détails qui leur donnent une seconde histoire.",
    contactEmail: "bonjour@kaplou.fr",
    instagramUrl: null,
    atelierLocation: "Retrait à l’atelier sur rendez-vous",
  }).onConflictDoNothing();
  const [settings] = await db.select().from(siteSettingsTable).where(eq(siteSettingsTable.id, "main"));
  res.json(GetSiteSettingsResponse.parse({
    id: settings.id,
    tagline: settings.tagline,
    about_text: settings.aboutText,
    contact_email: settings.contactEmail,
    instagram_url: settings.instagramUrl,
    atelier_location: settings.atelierLocation,
  }));
});

router.patch("/settings", async (req, res): Promise<void> => {
  const parsed = UpdateSiteSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const current = await db.select().from(siteSettingsTable).where(eq(siteSettingsTable.id, "main"));
  const values = {
    id: "main",
    tagline: parsed.data.tagline ?? current[0]?.tagline ?? "Les petites créations de Kaplou",
    aboutText: parsed.data.about_text ?? current[0]?.aboutText ?? "",
    contactEmail: parsed.data.contact_email ?? current[0]?.contactEmail ?? "bonjour@kaplou.fr",
    instagramUrl: parsed.data.instagram_url ?? current[0]?.instagramUrl ?? null,
    atelierLocation: parsed.data.atelier_location ?? current[0]?.atelierLocation ?? null,
  };
  const [settings] = current.length
    ? await db.update(siteSettingsTable).set(values).where(eq(siteSettingsTable.id, "main")).returning()
    : await db.insert(siteSettingsTable).values(values).returning();
  res.json(UpdateSiteSettingsResponse.parse({
    id: settings.id,
    tagline: settings.tagline,
    about_text: settings.aboutText,
    contact_email: settings.contactEmail,
    instagram_url: settings.instagramUrl,
    atelier_location: settings.atelierLocation,
  }));
});

router.get("/orders", async (_req, res): Promise<void> => {
  const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(100);
  const mapped = orders.map((order) => ({
    id: order.id,
    product_id: order.productId,
    product_title: order.productTitle,
    amount: order.amountCents / 100,
    currency: order.currency.toUpperCase(),
    quantity: order.quantity,
    status: order.status,
    fulfillment: order.fulfillment,
    created_at: order.createdAt,
  }));
  res.json(ListOrdersResponse.parse(mapped));
});

router.post("/contact", async (req, res): Promise<void> => {
  const parsed = SendContactMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await db.insert(contactMessagesTable).values({
    id: crypto.randomUUID(),
    name: parsed.data.name,
    email: parsed.data.email,
    message: parsed.data.message,
    interestedInSoldCreation: parsed.data.interested_in_sold_creation ?? false,
  });
  res.status(201).json(SendContactMessageResponse.parse({ message: "Votre message a bien été envoyé." }));
});

router.post("/checkout", async (req, res): Promise<void> => {
  const parsed = CreateCheckoutBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const product = await findProduct(parsed.data.product_id);
  if (!product || product.status !== "available" || !product.stripe_price_id) {
    res.status(409).json({ error: "Cette création n’est plus disponible." });
    return;
  }
  if (product.stock !== null) {
    const [pending] = await db.select({ value: count() }).from(ordersTable).where(
      and(eq(ordersTable.productId, product.id), eq(ordersTable.status, "pending")),
    );
    const reserved = Number(pending?.value ?? 0);
    if (reserved + parsed.data.quantity > product.stock) {
      res.status(409).json({ error: "La quantité demandée n’est plus disponible." });
      return;
    }
  }
  const orderId = crypto.randomUUID();
  await db.insert(ordersTable).values({
    id: orderId,
    productId: product.id,
    productTitle: product.title,
    amountCents: Math.round(product.price * 100 * parsed.data.quantity),
    currency: product.currency.toLowerCase(),
    quantity: parsed.data.quantity,
    fulfillment: parsed.data.fulfillment,
    status: "pending",
  });
  try {
    const stripe = await getUncachableStripeClient();
    const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0] ?? req.get("host")}`;
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{ price: product.stripe_price_id, quantity: parsed.data.quantity }],
      success_url: `${baseUrl}/creation/${product.slug}?paid=1`,
      cancel_url: `${baseUrl}/creation/${product.slug}`,
      metadata: { order_id: orderId, product_id: product.id },
      ...(parsed.data.fulfillment === "shipping" && product.shipping_price > 0
        ? {
            shipping_options: [{
              shipping_rate_data: {
                type: "fixed_amount" as const,
                fixed_amount: {
                  amount: Math.round(product.shipping_price * 100),
                  currency: product.currency.toLowerCase(),
                },
                display_name: "Expédition",
              },
            }],
          }
        : {}),
    });
    await db.update(ordersTable).set({ stripeCheckoutSessionId: session.id }).where(eq(ordersTable.id, orderId));
    if (!session.url) throw new Error("Stripe did not return a checkout URL.");
    res.json(CreateCheckoutResponse.parse({ checkout_url: session.url, order_id: orderId }));
  } catch (error) {
    await db.update(ordersTable).set({ status: "cancelled" }).where(eq(ordersTable.id, orderId));
    logger.error({ error, orderId }, "Unable to create Stripe checkout session");
    res.status(502).json({ error: "Le paiement est momentanément indisponible." });
  }
});

export default router;