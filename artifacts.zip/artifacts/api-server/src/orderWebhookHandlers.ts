import { eq, sql } from "drizzle-orm";
import { db, ordersTable } from "@workspace/db";
import { getUncachableStripeClient } from "./stripeClient";

type StripeCheckoutEvent = {
  type?: string;
  data?: { object?: { id?: string; payment_status?: string; metadata?: Record<string, string> } };
};

export async function processApplicationWebhook(payload: Buffer): Promise<void> {
  const event = JSON.parse(payload.toString("utf8")) as StripeCheckoutEvent;
  if (event.type !== "checkout.session.completed") return;

  const session = event.data?.object;
  const orderId = session?.metadata?.order_id;
  const productId = session?.metadata?.product_id;
  if (!orderId || !productId || session.payment_status !== "paid") return;

  const updated = await db
    .update(ordersTable)
    .set({ status: "paid" })
    .where(eq(ordersTable.id, orderId))
    .returning();
  if (!updated[0]) return;

  // Stripe is the source of truth for catalog data. The lock makes a unique
  // piece's stock decrement safe when multiple webhook deliveries arrive.
  const stripe = await getUncachableStripeClient();
  await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${productId}))`);
    const product = await stripe.products.retrieve(productId);
    const currentStock = product.metadata.stock;
    if (currentStock === undefined || currentStock === "") return;
    const nextStock = Math.max(0, Number(currentStock) - (updated[0]?.quantity ?? 1));
    await stripe.products.update(productId, {
      metadata: {
        stock: String(nextStock),
        status: nextStock === 0 ? "sold" : product.metadata.status ?? "available",
        updated_at: new Date().toISOString(),
      },
    });
  });
}