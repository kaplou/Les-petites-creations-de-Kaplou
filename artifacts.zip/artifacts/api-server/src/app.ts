import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { WebhookHandlers } from "./webhookHandlers";
import { processApplicationWebhook } from "./orderWebhookHandlers";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());

// Stripe requires the raw request body for signature verification. This route
// must stay before express.json(), otherwise webhook signatures cannot verify.
app.post(
  "/api/stripe/webhook",
  express.raw({ type: "application/json" }),
  async (req, res): Promise<void> => {
    const signature = req.headers["stripe-signature"];
    if (typeof signature !== "string") {
      res.status(400).send("Missing Stripe signature");
      return;
    }
    try {
      await WebhookHandlers.processWebhook(req.body as Buffer, signature);
      await processApplicationWebhook(req.body as Buffer);
      res.json({ received: true });
    } catch (error) {
      logger.error({ error }, "Stripe webhook processing failed");
      res.status(400).send("Webhook processing failed");
    }
  },
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

export default app;
