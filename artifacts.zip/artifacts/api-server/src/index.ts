import app from "./app";
import { logger } from "./lib/logger";
import { getStripeSync } from "./stripeClient";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function start() {
  try {
    const sync = await getStripeSync();
    const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0] ?? "localhost"}`;
    await sync.findOrCreateManagedWebhook(`${baseUrl}/api/stripe/webhook`);
    await sync.syncBackfill();
    logger.info("Stripe sync initialized");
  } catch (error) {
    logger.error({ error }, "Stripe sync initialization failed; checkout remains unavailable until Stripe is connected");
  }

  app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  });
}

void start();
