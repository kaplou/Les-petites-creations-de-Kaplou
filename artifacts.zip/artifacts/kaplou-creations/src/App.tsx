import { type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Route, Router as WouterRouter, Switch, useLocation, useRoute } from "wouter";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  AboutPage,
  AdminPage,
  ContactPage,
  CreationFormPage,
  DetailPage,
  GalleryPage,
  HomePage,
} from "@/pages/kaplou-pages";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function RoutedPages() {
  const [location] = useLocation();
  const [, category] = useRoute("/category/:category");
  return (
    <ErrorBoundary resetKey={location}>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/nouveautes" component={() => <GalleryPage />} />
        <Route path="/category/:category" component={() => <GalleryPage category={category?.category} />} />
        <Route path="/creation/:slug" component={DetailPage} />
        <Route path="/a-propos" component={AboutPage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/admin/creation/new" component={() => <CreationFormPage />} />
        <Route path="/admin/creation/:id/edit" component={() => <CreationFormPage edit />} />
        <Route path="/admin" component={AdminPage} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <RoutedPages />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;