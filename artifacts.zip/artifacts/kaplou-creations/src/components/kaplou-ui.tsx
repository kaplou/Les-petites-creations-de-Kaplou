import { ArrowRight, Instagram, Menu, Minus, Plus, X } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { useState } from 'react';
import { useGetSiteSettings, useHealthCheck } from '@workspace/api-client-react';
import type { Product } from '@workspace/api-client-react';

const categoryNames: Record<string, string> = {
  drawings: 'Dessins',
  'collages-papers': 'Papiers assemblés',
  'small-sculptures': 'Petites sculptures',
  'found-transformed': 'Objets trouvés',
};

export function categoryLabel(category: string) {
  return categoryNames[category] ?? category;
}

export function formatPrice(price: number, currency = 'EUR') {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency }).format(price);
}

export function ProductImage({ product, className = '' }: { product: Product; className?: string }) {
  const image = product.images?.[0];
  return image ? (
    <img src={image} alt={product.title} className={`image-reveal h-full w-full object-cover ${className}`} />
  ) : (
    <div className={`relative h-full w-full overflow-hidden bg-[#d6b38a] ${className}`}>
      <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full border-[18px] border-[#e77859]/70" />
      <div className="absolute bottom-8 left-8 h-20 w-36 -rotate-12 bg-[#185a51]/80" />
      <span className="absolute bottom-4 right-5 font-mono-custom text-[10px] uppercase tracking-[.25em] text-[#f4edda]">Kaplou / {product.year ?? 'atelier'}</span>
    </div>
  );
}

export function ProductCard({ product, featured = false }: { product: Product; featured?: boolean }) {
  return (
    <Link href={`/creation/${product.slug}`} className={`group block ${featured ? 'md:col-span-2' : ''}`} data-testid={`link-creation-${product.id}`}>
      <article className="hover-lift relative overflow-hidden border border-foreground/15 bg-card">
        <div className={`${featured ? 'aspect-[16/10]' : 'aspect-[4/5]'} overflow-hidden bg-secondary/50`}>
          <ProductImage product={product} />
        </div>
        <div className="flex items-start justify-between gap-3 p-4 md:p-5">
          <div>
            <p className="font-mono-custom text-[10px] uppercase tracking-[.18em] text-muted-foreground">{categoryLabel(product.category)}</p>
            <h3 className="mt-1 font-display text-xl leading-tight md:text-2xl">{product.title}</h3>
          </div>
          <span className="shrink-0 font-mono-custom text-xs">{formatPrice(product.price, product.currency)}</span>
        </div>
        {product.status !== 'available' && (
          <span className="absolute left-3 top-3 bg-primary px-2 py-1 font-mono-custom text-[10px] uppercase tracking-widest text-primary-foreground">{product.status === 'sold' ? 'Vendu' : 'Épuisé'}</span>
        )}
        {product.featured && <span className="absolute right-3 top-3 bg-accent px-2 py-1 font-mono-custom text-[10px] uppercase tracking-widest text-accent-foreground">À part</span>}
      </article>
    </Link>
  );
}

export function SectionKicker({ children }: { children: string }) {
  return <p className="font-mono-custom text-[10px] uppercase tracking-[.25em] text-muted-foreground">{children}</p>;
}

export function LoadingGrid({ count = 4 }: { count?: number }) {
  return <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">{Array.from({ length: count }).map((_, i) => <div className="animate-pulse" key={i}><div className="aspect-[4/5] bg-secondary/60" /><div className="mt-3 h-3 w-2/3 bg-secondary/60" /><div className="mt-2 h-3 w-1/3 bg-secondary/60" /></div>)}</div>;
}

export function QueryState({ error, onRetry }: { error?: unknown; onRetry: () => void }) {
  if (!error) return null;
  return <div className="border border-accent/50 bg-accent/10 px-5 py-8 text-center" data-testid="status-query-error"><p className="font-display text-2xl">Le tiroir est momentanément fermé.</p><p className="mt-2 text-sm text-muted-foreground">Un petit souci technique, et les pièces sont toujours là.</p><button onClick={onRetry} className="mt-5 border border-foreground px-4 py-2 font-mono-custom text-[10px] uppercase tracking-widest transition-colors hover:bg-primary hover:text-primary-foreground" data-testid="button-retry">Réessayer</button></div>;
}

export function EmptyState({ title = 'Rien ici, pour le moment.' }: { title?: string }) {
  return <div className="border border-dashed border-foreground/25 px-6 py-20 text-center" data-testid="status-empty"><div className="mx-auto mb-5 h-16 w-16 rotate-3 border border-foreground/30 bg-secondary/50" /><p className="font-display text-3xl">{title}</p><p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-muted-foreground">Les mains de l’atelier travaillent déjà à la prochaine pièce.</p></div>;
}

export function SiteShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data: settings } = useGetSiteSettings();
  const { isError: apiDown } = useHealthCheck();
  const links = [
    { href: '/', label: 'L’atelier' },
    { href: '/nouveautes', label: 'Nouveautés' },
    { href: '/a-propos', label: 'À propos' },
    { href: '/contact', label: 'Écrire à Kaplou' },
  ];
  return <div className="min-h-[100dvh] paper-grain">
    <header className="relative z-20 border-b border-foreground/15 bg-background/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1380px] items-center justify-between px-5 py-5 md:px-10">
        <Link href="/" className="group flex items-center gap-3" data-testid="link-logo">
          <span className="flex h-10 w-10 rotate-[-8deg] items-center justify-center bg-primary font-display text-2xl text-primary-foreground transition-transform group-hover:rotate-0">K</span>
          <span className="leading-none"><span className="block font-display text-lg">Les petites créations</span><span className="font-mono-custom text-[9px] uppercase tracking-[.2em] text-muted-foreground">de Kaplou</span></span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex" aria-label="Navigation principale">
          {links.map(link => <Link key={link.href} href={link.href} className={`font-mono-custom text-[10px] uppercase tracking-[.16em] transition-colors hover:text-accent ${location === link.href ? 'text-accent' : 'text-foreground/75'}`} data-testid={`link-nav-${link.label.toLowerCase().replaceAll(' ', '-')}`}>{link.label}</Link>)}
        </nav>
        <button className="border border-foreground/20 p-2 md:hidden" onClick={() => setMobileOpen(!mobileOpen)} data-testid="button-mobile-menu" aria-label="Ouvrir le menu">{mobileOpen ? <X size={18} /> : <Menu size={18} />}</button>
      </div>
      {mobileOpen && <nav className="border-t border-foreground/15 px-5 py-4 md:hidden" aria-label="Navigation mobile">{links.map(link => <Link onClick={() => setMobileOpen(false)} key={link.href} href={link.href} className="block border-b border-foreground/10 py-4 font-mono-custom text-[11px] uppercase tracking-[.16em]" data-testid={`link-mobile-${link.label.toLowerCase().replaceAll(' ', '-')}`}>{link.label}</Link>)}</nav>}
    </header>
    {apiDown && <div className="bg-accent px-5 py-2 text-center font-mono-custom text-[10px] uppercase tracking-widest text-accent-foreground" data-testid="status-api">L’atelier se reconnecte…</div>}
    <main>{children}</main>
    <footer className="mt-24 border-t border-foreground/15 bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-[1380px] gap-10 px-5 py-12 md:grid-cols-[1.4fr_1fr_1fr] md:px-10 md:py-16">
        <div><p className="font-display text-3xl">Faire avec ce qui est là.</p><p className="mt-3 max-w-xs text-sm leading-6 text-primary-foreground/70">{settings?.tagline ?? 'Des objets uniques, dessinés, découpés, assemblés à la main.'}</p></div>
        <div><SectionKicker>Se promener</SectionKicker><div className="mt-3 flex flex-col gap-2 text-sm text-primary-foreground/75"><Link href="/nouveautes" className="hover:text-secondary" data-testid="link-footer-new">Les dernières pièces</Link><Link href="/a-propos" className="hover:text-secondary" data-testid="link-footer-about">L’histoire de Kaplou</Link><Link href="/contact" className="hover:text-secondary" data-testid="link-footer-contact">Le carnet de correspondance</Link></div></div>
        <div><SectionKicker>L’atelier</SectionKicker><p className="mt-3 text-sm leading-6 text-primary-foreground/75">{settings?.atelier_location ?? 'France, quelque part entre les papiers et la lumière.'}</p>{settings?.instagram_url && <a href={settings.instagram_url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-sm hover:text-secondary" data-testid="link-instagram"><Instagram size={15} /> Instagram</a>}</div>
      </div>
      <div className="border-t border-primary-foreground/15 px-5 py-4 text-center font-mono-custom text-[9px] uppercase tracking-[.25em] text-primary-foreground/45">Objets singuliers · petits tirages · tout doucement</div>
    </footer>
  </div>;
}

export function QuantityControl({ value, onChange, max = 9 }: { value: number; onChange: (value: number) => void; max?: number }) {
  return <div className="inline-flex items-center border border-foreground/30"><button type="button" className="p-3 hover:bg-secondary" onClick={() => onChange(Math.max(1, value - 1))} data-testid="button-quantity-minus"><Minus size={14} /></button><span className="min-w-10 text-center font-mono-custom text-xs" data-testid="text-quantity">{value}</span><button type="button" className="p-3 hover:bg-secondary" onClick={() => onChange(Math.min(max, value + 1))} data-testid="button-quantity-plus"><Plus size={14} /></button></div>;
}

export { ArrowRight };